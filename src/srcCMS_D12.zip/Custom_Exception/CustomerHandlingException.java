package Custom_Exception;

public class CustomerHandlingException extends Exception{
    public CustomerHandlingException(String msg) {
        super(msg);
    }
}
